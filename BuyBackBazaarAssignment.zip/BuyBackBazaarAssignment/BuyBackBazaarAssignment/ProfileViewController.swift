//
//  ViewController.swift
//  BuyBackBazaarAssignment
//
//  Created by Raja on 18/12/18.
//  Copyright © 2018 RajaReddy. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var ivProfile: UIImageView!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfMobile: UITextField!
    @IBOutlet weak var containerTopConstraint: NSLayoutConstraint!
    
    
    fileprivate var keyboardBottomConstraint: NSLayoutConstraint!
    fileprivate var imagePickerController = UIImagePickerController()
    fileprivate var selectedTextFieldPosition = CGRect()
    
    let keyboardView: UIView = {
        let view = UIView(frame: CGRect.zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.lightGray
        return view
    }()
    
    let lblPlaceHolder: UILabel = {
        let lbl = UILabel(frame: CGRect.zero)
        lbl.font = UIFont.systemFont(ofSize: 12)
        lbl.textColor = UIColor.gray
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.text = "Dismiss here -->"
        return lbl
    }()
    
    let doneBtn: UIButton = {
        let btn = UIButton(type: UIButton.ButtonType.system)
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitleColor(UIColor.white, for: UIControl.State.normal)
        btn.setTitle("Done", for: UIControl.State.normal)
        return btn
    }()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDidShow(_:)), name: UIResponder.keyboardDidShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
    }

    fileprivate func setupViews() {
        
        self.view.addSubview(keyboardView)
        
        keyboardBottomConstraint = keyboardView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)
        keyboardBottomConstraint.isActive = true
        
        [keyboardView.rightAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.rightAnchor),
         keyboardView.leftAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.leftAnchor),
         keyboardView.heightAnchor.constraint(equalToConstant: 50)].forEach { (constraint) in
            constraint.isActive = true
        }
        
        keyboardView.addSubview(lblPlaceHolder)
        [lblPlaceHolder.centerXAnchor.constraint(equalTo: self.keyboardView.centerXAnchor),
         lblPlaceHolder.centerYAnchor.constraint(equalTo: self.keyboardView.centerYAnchor)].forEach { (constraints) in
            constraints.isActive = true
        }
        
        keyboardView.addSubview(doneBtn)
        [doneBtn.rightAnchor.constraint(equalTo: self.keyboardView.rightAnchor, constant: -12),
         doneBtn.centerYAnchor.constraint(equalTo: keyboardView.centerYAnchor)].forEach { (constraint) in
            constraint.isActive = true
        }
        keyboardView.isHidden = true
        doneBtn.addTarget(self, action: #selector(self.doneBtnHandler(_:)), for: UIControl.Event.touchUpInside)
        
        ivProfile.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.didTapOnProfileImageView(_:))))
    }
    
    @objc fileprivate func doneBtnHandler(_ sender: Any) {
        self.view.endEditing(true)
        keyboardView.isHidden = true
        containerTopConstraint.constant = 20
    }
    
    @objc fileprivate func didTapOnProfileImageView(_ sender: Any) {
        Alert.show(self, sourceView: ivProfile) { (isCameraSelected) in
            if (isCameraSelected) {
                self.picFromCamera()
            }else {
                self.picFromPhotos()
            }
        }
    }
    
    @objc fileprivate func keyboardWillShow(_ notification: Notification) {
        if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            let keyboardHeight = keyboardRectangle.height
            keyboardBottomConstraint.constant = -keyboardHeight
        }
    }
    
    fileprivate func handleKeyboardPosition() {
        if let keyviewFrame = keyboardView.superview?.convert(keyboardView.frame, to: nil) {
            let tfFrame = selectedTextFieldPosition.origin.y+selectedTextFieldPosition.height
            let keyboardYpos = keyviewFrame.origin.y
            if tfFrame > keyboardYpos {
                let diff = tfFrame-keyboardYpos
                containerTopConstraint.constant = 20-diff
            }
        }
    }
    
    @objc fileprivate func keyboardDidShow(_ notification: Notification) {
        keyboardView.isHidden = false
        handleKeyboardPosition()
    }

    fileprivate func picFromCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            imagePickerController.delegate = self
            imagePickerController.sourceType = .camera;
            imagePickerController.allowsEditing = true
            self.present(imagePickerController, animated: true, completion: nil)
        }else {
            Alert.show("Can not support for camera", viewController: self)
        }
    }
    
    fileprivate func picFromPhotos() {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) {
            imagePickerController.delegate = self
            imagePickerController.sourceType = .savedPhotosAlbum;
            imagePickerController.allowsEditing = true
            self.present(imagePickerController, animated: true, completion: nil)
        }
    }
    
    @IBAction func saveBtnHandler(_ sender: Any) {
        if !tfName.text!.isBlank {
            if tfEmail.text!.isValidEmail {
                if tfMobile.text!.isValidPhoneNumber {
                    Alert.show("Name: \(tfName.text!)\nEmail: \(tfEmail.text!)\nPhone Number: \(tfMobile.text!)", viewController: self)
                }else {
                    Alert.show("Please enter a valid Phone Number", viewController: self)
                }
            }else {
                Alert.show("Please enter a valid email Address", viewController: self)
            }
        }else {
            Alert.show("Please enter Name", viewController: self)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.dismiss(animated: true, completion: nil)
        ivProfile.contentMode = .scaleAspectFill
        ivProfile.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if let tfFrame = textField.superview?.convert(textField.frame, to: nil) {
            selectedTextFieldPosition = tfFrame
        }
        switch textField.tag {
        case 101:
            lblPlaceHolder.text = "Name"
        case 201:
            lblPlaceHolder.text = "Email"
            break
        case 301:
            lblPlaceHolder.text = "+91 9876543210"
            break
        default:
            break
        }
        if keyboardBottomConstraint.constant < 0 {
            handleKeyboardPosition()
        }
    }
    
    
}

