//
//  Alert.swift
//  BuyBackBazaarAssignment
//
//  Created by Raja on 18/12/18.
//  Copyright © 2018 RajaReddy. All rights reserved.
//

import UIKit

class Alert {
    
    static func show(_ message: String, viewController: UIViewController) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (alertAction) in}))
        viewController.present(alertController, animated: true, completion: nil)
    }
    
    static func show(_ viewController: UIViewController, sourceView: UIView, complitionHandler: @escaping(_ didSelectCamera: Bool) -> ()) {
        let alertController = UIAlertController(title: "Select profile from", message: nil, preferredStyle: UIAlertController.Style.actionSheet)
        alertController.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: { (alertAction) in}))
        alertController.addAction(UIAlertAction(title: "Camera", style: UIAlertAction.Style.default, handler: { (alertAction) in
            complitionHandler(true)
        }))
        alertController.addAction(UIAlertAction(title: "Photos", style: UIAlertAction.Style.default, handler: { (alertAction) in
            complitionHandler(false)
        }))
        
        if let popover = alertController.popoverPresentationController {
            popover.sourceView = sourceView
        }
        viewController.present(alertController, animated: true, completion: nil)
    }
    
}
